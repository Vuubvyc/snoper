# Tori Sniper – APK

Android-sovellus, joka tarkkailee tori.fi-hakuja ja ilmoittaa uusista osumista.
Ei vaadi Termuxia. Ilmoitusta napauttamalla ilmoitus avautuu selaimeen.

## APK:n kääntäminen pilvessä (helpoin – ei tarvita omaa konetta)

1. Luo ilmainen tili osoitteessa https://github.com ja kirjaudu sisään.
2. Paina **+** (oikea yläkulma) → **New repository**. Anna nimeksi esim. `tori-sniper`,
   valitse **Public** ja luo repo.
3. Lataa tämän kansion tiedostot repoon: repon sivulla **Add file → Upload files**,
   raahaa mukaan `main.py`, `buildozer.spec` ja kansio `.github`. Paina **Commit changes**.
   - `.github/workflows/build.yml` täytyy säilyttää juuri tuossa polussa.
4. Mene repon **Actions**-välilehdelle. Käännös käynnistyy automaattisesti.
   Ensimmäinen kääntö kestää ~20–40 min (lataa Android-työkalut).
5. Kun ajo on valmis (vihreä ✓), avaa se ja lataa **tori-sniper-apk** kohdasta
   *Artifacts* alareunasta. Sisällä on `.apk`.

## APK:n asennus puhelimeen

1. Siirrä `.apk` puhelimeen ja avaa se.
2. Android kysyy luvan asentaa tuntemattomasta lähteestä – salli se.
3. Avaa sovellus, salli ilmoitukset.

## Käyttö

1. Liitä torin hakuosoite (tee haku torissa suodattimineen ja kopioi selaimen osoite).
2. Aseta maksimihinta ja halutessasi kielletyt sanat (esim. `rikki, osiksi`).
3. Paina **Käynnistä**. Ensimmäinen kierros vain opettelee nykyiset ilmoitukset;
   sen jälkeen uusista osumista tulee ilmoitus.

## Huomioita

- Tausta-ajo: Android voi pysäyttää sovelluksen, kun ruutu on pois päältä pitkään.
  Poista akunsäästö tältä sovellukselta (Asetukset → Sovellukset → Tori Sniper →
  Akku → Rajoittamaton). Luotettavinta ajo on, kun sovellus on auki.
- Pidä tarkistusväli maltillisena (oletus 180 s). Liian tiheä haku kuormittaa toria
  ja voi johtaa eston. Käytä vain omiin hakuihisi.
- Älä automatisoi viestejä myyjille; lähetä yhteydenotot itse.

## Paikallinen kääntäminen (vaihtoehto, Linux)

```
pip install buildozer cython
sudo apt install -y zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config \
     zlib1g-dev libncurses-dev libffi-dev libssl-dev
buildozer android debug
```
APK syntyy `bin/`-kansioon.
