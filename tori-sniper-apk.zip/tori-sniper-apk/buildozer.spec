[app]
title = Tori Sniper
package.name = torisniper
package.domain = fi.torisniper
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0
requirements = python3,kivy==2.3.0,requests,urllib3,chardet,idna,certifi,charset-normalizer,beautifulsoup4,soupsieve,pyjnius,android
orientation = portrait
fullscreen = 0

# Android
android.permissions = INTERNET, POST_NOTIFICATIONS, WAKE_LOCK, FOREGROUND_SERVICE
android.api = 34
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = 1
android.release_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 0
