"""
Tori Sniper – Android-sovellus (Kivy)
Tarkkailee tori.fi-hakuja ja ilmoittaa uusista osumista.

Ei vaadi Termuxia: tämä kääntyy APK:ksi (ks. README.md).
"""

import json
import os
import re
import threading
import time
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

import requests
from bs4 import BeautifulSoup

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.utils import platform

# --------------------------------------------------------------------------

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36"),
    "Accept-Language": "fi-FI,fi;q=0.9",
}
ITEM_RE = re.compile(r"/recommerce/forsale/item/(\d+)")
TARKISTUSVALI_S = 180  # sekuntia


def uusimmat_ensin(url):
    p = urlparse(url)
    q = parse_qs(p.query)
    q["sort"] = ["PUBLISHED_DESC"]
    return urlunparse(p._replace(query=urlencode(q, doseq=True)))


def parse_hinta(teksti):
    if not teksti:
        return None
    if "annetaan" in teksti.lower():
        return 0
    numerot = re.sub(r"[^\d]", "", teksti.split("€")[0])
    return int(numerot) if numerot else None


def hae_ilmoitukset(url):
    r = requests.get(uusimmat_ensin(url), headers=HEADERS, timeout=25)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    tulokset = {}
    for article in soup.find_all("article"):
        linkki = article.find("a", href=ITEM_RE)
        if not linkki:
            continue
        item_id = ITEM_RE.search(linkki["href"]).group(1)
        teksti = article.get_text(" ", strip=True)
        if "Paalupaikka" in teksti:
            continue
        otsikko_el = article.find(["h2", "h3"])
        otsikko = otsikko_el.get_text(" ", strip=True) if otsikko_el else teksti[:80]
        hinta_m = re.search(r"(\d[\d\s ]*)\s*€|Annetaan", teksti)
        hinta = parse_hinta(hinta_m.group(0)) if hinta_m else None
        tulokset[item_id] = {
            "id": item_id, "otsikko": otsikko, "hinta": hinta,
            "url": f"https://www.tori.fi/recommerce/forsale/item/{item_id}",
        }
    if not tulokset:
        for a in soup.find_all("a", href=ITEM_RE):
            item_id = ITEM_RE.search(a["href"]).group(1)
            tulokset.setdefault(item_id, {
                "id": item_id, "otsikko": a.get_text(" ", strip=True) or f"Ilmoitus {item_id}",
                "hinta": None,
                "url": f"https://www.tori.fi/recommerce/forsale/item/{item_id}",
            })
    return list(tulokset.values())


def kelpaa(ilm, maksimi, kielletyt, pakolliset):
    otsikko = ilm["otsikko"].lower()
    h = ilm["hinta"]
    if maksimi is not None and h is not None and h > maksimi:
        return False
    if any(s and s.lower() in otsikko for s in kielletyt):
        return False
    pakolliset = [s for s in pakolliset if s]
    if pakolliset and not any(s.lower() in otsikko for s in pakolliset):
        return False
    return True


# ----------------------------- Android-ilmoitus ---------------------------

def android_notify(otsikko, teksti, url):
    """Näyttää Android-ilmoituksen, jota napauttamalla ilmoitus avautuu."""
    try:
        from jnius import autoclass, cast
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        Context = autoclass("android.content.Context")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        PendingIntent = autoclass("android.app.PendingIntent")
        Notification = autoclass("android.app.Notification")
        NotificationManager = autoclass("android.app.NotificationManager")
        Builder = autoclass("android.app.Notification$Builder")
        NotificationChannel = autoclass("android.app.NotificationChannel")
        BuildVersion = autoclass("android.os.Build$VERSION")

        activity = PythonActivity.mActivity
        service = activity.getSystemService(Context.NOTIFICATION_SERVICE)
        manager = cast(NotificationManager, service)

        channel_id = "tori_sniper"
        if BuildVersion.SDK_INT >= 26:
            ch = NotificationChannel(channel_id, "Tori Sniper",
                                     NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(ch)
            builder = Builder(activity, channel_id)
        else:
            builder = Builder(activity)

        intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        flags = PendingIntent.FLAG_UPDATE_CURRENT
        if BuildVersion.SDK_INT >= 23:
            flags = flags | PendingIntent.FLAG_IMMUTABLE
        pending = PendingIntent.getActivity(activity, int(time.time()) & 0xFFFFFF,
                                            intent, flags)

        icon = activity.getApplicationInfo().icon
        builder.setContentTitle(otsikko)
        builder.setContentText(teksti)
        builder.setSmallIcon(icon)
        builder.setContentIntent(pending)
        builder.setAutoCancel(True)
        manager.notify(int(time.time()) & 0xFFFFFF, builder.build())
    except Exception as e:
        print(f"Ilmoitusvirhe: {e}")


def avaa_url(url):
    if platform == "android":
        try:
            from jnius import autoclass, cast
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            Intent = autoclass("android.content.Intent")
            Uri = autoclass("android.net.Uri")
            activity = PythonActivity.mActivity
            intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            activity.startActivity(intent)
        except Exception as e:
            print(f"Avausvirhe: {e}")
    else:
        import webbrowser
        webbrowser.open(url)


# --------------------------------- UI -------------------------------------

class SniperUI(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(10),
                         spacing=dp(8), **kw)
        self.app = app

        self.add_widget(Label(text="[b]Tori Sniper[/b]", markup=True,
                              size_hint_y=None, height=dp(36), font_size="20sp"))

        self.url_in = TextInput(hint_text="Torin hakuosoite (https://www.tori.fi/...)",
                                text=app.cfg["url"], multiline=False,
                                size_hint_y=None, height=dp(44))
        self.add_widget(self.url_in)

        rivi = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        self.hinta_in = TextInput(hint_text="Max hinta €", text=str(app.cfg["max_hinta"] or ""),
                                  multiline=False, input_filter="int")
        self.kielletyt_in = TextInput(hint_text="Kielletyt sanat (pilkulla)",
                                      text=", ".join(app.cfg["kielletyt"]), multiline=False)
        rivi.add_widget(self.hinta_in)
        rivi.add_widget(self.kielletyt_in)
        self.add_widget(rivi)

        self.start_btn = Button(text="Käynnistä", size_hint_y=None, height=dp(50),
                                background_color=(0.1, 0.6, 0.3, 1))
        self.start_btn.bind(on_release=self.toggle)
        self.add_widget(self.start_btn)

        self.status = Label(text="Pysäytetty", size_hint_y=None, height=dp(28),
                            color=(0.7, 0.7, 0.7, 1))
        self.add_widget(self.status)

        sv = ScrollView()
        self.lista = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(6))
        self.lista.bind(minimum_height=self.lista.setter("height"))
        sv.add_widget(self.lista)
        self.add_widget(sv)

    def toggle(self, *_):
        if self.app.running:
            self.app.stop_monitor()
            self.start_btn.text = "Käynnistä"
            self.start_btn.background_color = (0.1, 0.6, 0.3, 1)
            self.set_status("Pysäytetty")
        else:
            self.app.cfg["url"] = self.url_in.text.strip()
            self.app.cfg["max_hinta"] = int(self.hinta_in.text) if self.hinta_in.text else None
            self.app.cfg["kielletyt"] = [s.strip() for s in self.kielletyt_in.text.split(",") if s.strip()]
            self.app.save_cfg()
            if not self.app.cfg["url"]:
                self.set_status("Syötä hakuosoite ensin")
                return
            self.app.start_monitor()
            self.start_btn.text = "Pysäytä"
            self.start_btn.background_color = (0.7, 0.2, 0.2, 1)
            self.set_status("Käynnissä…")

    @mainthread
    def set_status(self, t):
        self.status.text = t

    @mainthread
    def lisaa_osuma(self, ilm):
        hinta = "Annetaan" if ilm["hinta"] == 0 else (
            f"{ilm['hinta']} €" if ilm["hinta"] is not None else "? €")
        b = Button(text=f"{ilm['otsikko']}\n{hinta}", size_hint_y=None,
                   height=dp(60), halign="left", valign="middle")
        b.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        b.bind(on_release=lambda *_: avaa_url(ilm["url"]))
        self.lista.add_widget(b, index=len(self.lista.children))


class ToriSniperApp(App):
    def build(self):
        self.title = "Tori Sniper"
        self.running = False
        self.thread = None
        self.seen = set()
        self.load_cfg()
        if platform != "android":
            Window.size = (400, 720)
        self.ui = SniperUI(self)
        if platform == "android":
            self._request_permissions()
        return self.ui

    # --- asetukset ---
    def cfg_path(self):
        return os.path.join(self.user_data_dir, "config.json")

    def load_cfg(self):
        self.cfg = {"url": "", "max_hinta": None, "kielletyt": []}
        try:
            with open(self.cfg_path()) as f:
                self.cfg.update(json.load(f))
        except Exception:
            pass

    def save_cfg(self):
        try:
            with open(self.cfg_path(), "w") as f:
                json.dump(self.cfg, f)
        except Exception as e:
            print(f"Tallennusvirhe: {e}")

    def _request_permissions(self):
        try:
            from android.permissions import request_permissions, Permission
            request_permissions([Permission.INTERNET, Permission.POST_NOTIFICATIONS])
        except Exception as e:
            print(f"Lupavirhe: {e}")

    # --- monitorointi ---
    def start_monitor(self):
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop_monitor(self):
        self.running = False

    def _loop(self):
        ensimmainen = True
        while self.running:
            try:
                ilmoitukset = hae_ilmoitukset(self.cfg["url"])
                uudet = [i for i in ilmoitukset if i["id"] not in self.seen]
                for ilm in uudet:
                    self.seen.add(ilm["id"])
                    if ensimmainen:
                        continue
                    if kelpaa(ilm, self.cfg["max_hinta"], self.cfg["kielletyt"], []):
                        self.ui.lisaa_osuma(ilm)
                        if platform == "android":
                            hinta = "Annetaan" if ilm["hinta"] == 0 else (
                                f"{ilm['hinta']} €" if ilm["hinta"] is not None else "? €")
                            android_notify("Tori: uusi osuma",
                                           f"{ilm['otsikko']} – {hinta}", ilm["url"])
                tila = "Alustettu, odotetaan uusia…" if ensimmainen else f"{len(ilmoitukset)} ilmoitusta"
                self.ui.set_status(f"{time.strftime('%H:%M')} · {tila}")
                ensimmainen = False
            except Exception as e:
                self.ui.set_status(f"Virhe: {e}")
            for _ in range(TARKISTUSVALI_S):
                if not self.running:
                    break
                time.sleep(1)


if __name__ == "__main__":
    ToriSniperApp().run()
